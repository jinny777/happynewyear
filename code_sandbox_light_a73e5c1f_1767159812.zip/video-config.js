// 비디오 설정 파일
// 보안을 위해 별도 파일로 분리
const VIDEO_CONFIG = {
    url: 'https://www.genspark.ai/api/files/s/W9itgugs?token=Z0FBQUFBQnBWS0tMaEZSV0piMkZEb1Nxb3NoR3hFVmtnOEdHbWtfVTFrVktGRzhZd2dLSVptcGl4cm5vOVRSdUJIelNhU3VaYlVmU0NBclMxZkdvd3JEWm1pVHdlVTBBdk91X25tMWxOQ3RLdXpLZVZ1cTJqUGRrTk5rRFVjQlJTM1BqanRScHFrN2MyaXBncVVuT2hLa2MxNGZZczlJSm9GdUhiRG9XbEtSaXhyZ3RKVU80dUdrdkd2TlVuQjVKek1kc0Q2V1puYWJLSkh6NW5KbThXcGNCRkUxZmxuMEs2YV9oc3l4OXlNX3M0STEzRWVpb3o4V045elRGdHRmZ2xNSEZHMnhqeVhsLVNXT2VzVVNrWnMzUVJ6a3BVZGwxNHc9PQ',
    type: 'video/mp4'
};
